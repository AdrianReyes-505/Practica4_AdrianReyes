m=10;
r=0.05;
k=100;
open("Movimiento_Rotacional_simulink")